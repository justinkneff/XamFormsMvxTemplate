﻿using MvvmCross.Core.ViewModels;

namespace $safeprojectname$.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
    }
}
